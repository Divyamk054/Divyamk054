// ---------------- LOGIN ----------------
document.addEventListener("DOMContentLoaded", () => {
  const loginBtn = document.getElementById("loginBtn");

  // Login page → redirect to dashboard
  if (loginBtn) {
    loginBtn.addEventListener("click", () => {
      window.location.href = "/dashboard.html";
    });
  }

  // Dashboard page → load feedback
  if (document.getElementById("feedbackList")) {
    loadFeedback();
  }
});

// ---------------- FEEDBACK ----------------
function submitFeedback() {
  const textArea = document.getElementById("feedbackText");
  const text = textArea.value.trim();

  if (text === "") {
    alert("Please enter feedback");
    return;
  }

  fetch("/feedback", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ feedback: text })
  })
    .then(() => {
      textArea.value = "";
      loadFeedback();
    })
    .catch(err => {
      console.error("Error submitting feedback", err);
    });
}

function loadFeedback() {
  fetch("/feedback")
    .then(res => res.json())
    .then(data => {
      const list = document.getElementById("feedbackList");
      list.innerHTML = "";

      data.forEach(item => {
        const li = document.createElement("li");
        li.textContent = item.feedback;
        list.appendChild(li);
      });
    });
}

// ---------------- AI SUMMARY ----------------
function generateSummary() {
  fetch("/feedback")
    .then(res => res.json())
    .then(data => {
      const summaryEl = document.getElementById("aiSummary");

      if (!data || data.length === 0) {
        summaryEl.innerText = "AI Insight: No feedback available.";
        return;
      }

      // Simple keyword-based AI summary
      let words = data
        .map(item => item.feedback.toLowerCase())
        .join(" ")
        .split(/\s+/);

      let keywords = {};
      words.forEach(word => {
        if (word.length > 3) {
          keywords[word] = (keywords[word] || 0) + 1;
        }
      });

      let topWords = Object.entries(keywords)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5)
        .map(item => item[0]);

      summaryEl.innerText =
        `AI Insight: Users frequently mention → ${topWords.join(", ")}`;
    })
    .catch(err => {
      console.error("Error generating summary", err);
    });
}

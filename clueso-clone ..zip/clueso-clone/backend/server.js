const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");

const app = express();
app.use(cors());
app.use(express.json());

// Serve frontend files
app.use(express.static(path.join(__dirname, "..", "frontend")));

// Default route → Login page
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "frontend", "index.html"));
});

// Get feedback
app.get("/feedback", (req, res) => {
  fs.readFile("feedback.json", "utf8", (err, data) => {
    if (err) return res.json([]);
    res.json(JSON.parse(data || "[]"));
  });
});

// Save feedback
app.post("/feedback", (req, res) => {
  fs.readFile("feedback.json", "utf8", (err, data) => {
    let feedbacks = [];
    if (!err && data) feedbacks = JSON.parse(data);

    feedbacks.push(req.body);

    fs.writeFile("feedback.json", JSON.stringify(feedbacks, null, 2), () => {
      res.json({ success: true });
    });
  });
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
